const express = require('express');
const https = require('https');
const bodyParser = require('body-parser');
const path = require('path');
const ejs = require('ejs');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));

const publicPath = path.join(__dirname, '../public');
app.use(express.static(publicPath));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../public'));

app.get('/', (req, res) => {
    res.sendFile(path.join(publicPath, 'index.html'));
});

app.get('/weather', (req, res) => {
    res.sendFile(path.join(publicPath, 'weather.html'));
});

app.get('/dictionary', (req, res) => {
    res.sendFile(path.join(publicPath, 'dictionary.html'));
});


app.post('/weather', (req, res) => {
    const city = req.body.city;
    if (!city) {
        return res.send('Please enter a city name.');
    }
    const apiURL = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=0eb9fdd48b2210025bca29406a4868ba`;
    https.get(apiURL, (apiRes) => {
        let data = '';

        apiRes.on('data', (chunk) => {
            data += chunk;
        });

        apiRes.on('end', () => {
            try {
                const weatherData = JSON.parse(data);
                const temperatureKelvin = weatherData.main.temp;
                const temperatureCelsius = temperatureKelvin - 273.15;

                const details = {
                    cityName : city,
                    temperature: temperatureCelsius.toFixed(2),
                    description: weatherData.weather[0].description,
                    iconURL: `http://openweathermap.org/img/w/${weatherData.weather[0].icon}.png`,
                    coordinates: `${weatherData.coord.lat}, ${weatherData.coord.lon}`,
                    feelsLike: (weatherData.main.feels_like - 273.15).toFixed(2),
                    humidity: weatherData.main.humidity,
                    pressure: weatherData.main.pressure,
                    windSpeed: weatherData.wind.speed,
                    countryCode: weatherData.sys.country,
                    rainVolumeLast3Hours: weatherData.rain ? weatherData.rain['3h'] || 0 : 0
                };

                res.render('weatherResult', { details, yandexMapApiKey: '194c73d9-008e-43d7-be85-be34ca2a560a' });
            } catch (error) {
                console.error(error);
                res.send('Error parsing weather data.');
            }
        });
    }).on('error', (error) => {
        console.error(error);
        res.send('Error retrieving weather data.');
    });
});

app.post('/dictionary', (req, res) => {
    const word = req.body.word;
    if (!word) {
        return res.send('Please enter a word.');
    }
    const apiURL = `https://api.dictionaryapi.dev/api/v2/entries/en_US/${word}`;
    https.get(apiURL, (apiRes) => {
        let data = '';

        apiRes.on('data', (chunk) => {
            data += chunk;
        });

        apiRes.on('end', () => {
            try {
                const dictionaryData = JSON.parse(data);
                res.render('dictionaryResult', { dictionaryData });
            } catch (error) {
                console.error(error);
                res.send('Error parsing dictionary data.');
            }
        });
    }).on('error', (error) => {
        console.error(error);
        res.send('Error retrieving dictionary data.');
    });
});


app.listen(3000, () => {
    console.log(`Server is running on http://localhost:3000`);
});