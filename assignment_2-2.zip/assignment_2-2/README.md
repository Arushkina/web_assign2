Run node routes/app.js

and follow the link localhost:3000/